<?php
$db = new mysqli('localhost', 'root', 'root', 'test2201');
$db->query('SET NAMES UTF8');
