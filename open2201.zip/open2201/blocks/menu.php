   <div class='left_span'>
       <ul>
           <li><a href="index.php" class=activ>Добавить </a></li>
           <li><a href="done.php">Статус</a></li>
           <li><a href="edit.php">Редактировать </a></li>
       </ul>
   </div>